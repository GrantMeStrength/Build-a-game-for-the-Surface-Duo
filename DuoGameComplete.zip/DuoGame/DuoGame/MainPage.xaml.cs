﻿using SkiaSharp;
using SkiaSharp.Views.Forms;
using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.DualScreen;

namespace DuoGame
{
    public partial class MainPage : ContentPage
    {
        Stopwatch stopwatch = new Stopwatch();
        SKPoint targetLocation;
        int score = 0;
        int dx = 11, dy = 7; // Keep track of the Target motion 
        bool pageIsActive = true;
        SKBitmap targetBitmap;
        SKBitmap backgroundBitmap;
        const int screenheight = 2700;
        const int screenwidth = 1800;
        SKPaint redPaint, greenPaint, blackPaint;

        SKPoint newArrowStart, newArrowEnd;
        bool pullingArrow = false;

        ArrayList arrows = new ArrayList();



        public MainPage()
        {
            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            // This method is automatically called when the app appears

            base.OnAppearing();

            // Load the bitmaps
            targetBitmap = LoadBitmap("DuoGame.Images.target.png");
            backgroundBitmap = LoadBitmap("DuoGame.Images.skygrassbackground.png");

            // Define paint
            greenPaint = new SKPaint();
            greenPaint.StrokeWidth = 16;
            greenPaint.Color = new SKColor(0, 0xFF, 0);

            redPaint = new SKPaint();
            redPaint.StrokeWidth = 16;
            redPaint.TextSize = 64.0f;
            redPaint.Color = new SKColor(0xFF, 0, 0);

            blackPaint = new SKPaint();
            blackPaint.StrokeWidth = 16;
            blackPaint.Color = new SKColor(0, 0, 0);

            // Arrow launch point
            newArrowStart = new SKPoint(screenwidth / 2, screenheight - 320);

            // Target
            targetLocation.X = 200; targetLocation.Y = 100;

            // Start the animation loop
            AnimationLoop();
        }


        void OnCanvasViewPaintSurface(object sender, SKPaintSurfaceEventArgs args)
        {
            // This is called whenever the screen needs redrawn

            SKSurface surface = args.Surface;
            SKCanvas canvas = surface.Canvas;

            // Clear the screen
            canvas.DrawBitmap(backgroundBitmap, 0, 0);

            // Draw the score
            canvas.DrawText("Score: " + score.ToString(), 200.0f, 80.0f, redPaint);

            // To create the arrow launching control, draw a circle, and if it's touched and moved,
            // then change color and draw a line from the current circle to that location.

            if (pullingArrow)
            {
                canvas.DrawCircle(newArrowEnd, 64, blackPaint);
                canvas.DrawLine(newArrowStart, newArrowEnd, blackPaint);
            }
            else
            {
                canvas.DrawCircle(newArrowStart, 64, greenPaint);
            }


            // Draw the target
            canvas.DrawBitmap(targetBitmap, targetLocation);


            // Draw the arrows and check if they hit the target
            ArrayList cleanup = new ArrayList();

            foreach (ArrowClass arrow in arrows)
            {
                arrow.Move();
                if (arrow.GetState())
                {
                    canvas.DrawLine(arrow.GetStartLocation(), arrow.GetEndLocation(), blackPaint);
                    var range = distanceBetweenPoints(arrow.GetStartLocation(), new SKPoint(targetLocation.X + 128, targetLocation.Y + 128));
                    if (range < 8)
                    {
                        // Hit the target! You should add something specactular here, and update the score
                        cleanup.Add(arrow);
                        score = score + 100;
                        targetLocation.X = 100; targetLocation.Y = 100;
                    }
                }
                else
                {
                    cleanup.Add(arrow);
                }

            }

            // Clean-up any no-longer needed arrows
            foreach (ArrowClass oldArrow in cleanup)
            {
                arrows.Remove(oldArrow);
            }
        }

        async Task AnimationLoop()
        {
            // This just keeps going until the app isn't visible any more.

            while (pageIsActive)
            {

                stopwatch.Start();

                // Bounce the target around the screen
                targetLocation.X = targetLocation.X + dx;
                if (targetLocation.X < 0 || targetLocation.X > (screenwidth - 256)) dx = -dx;

                targetLocation.Y = targetLocation.Y + dy;
                if (targetLocation.Y < 0 || targetLocation.Y > (screenheight / 2) - 300) dy = -dy;

                canvasView.InvalidateSurface();
                await Task.Delay(TimeSpan.FromSeconds(1.0 / 30.0));

                stopwatch.Stop();
            }
        }

        private void OnTouch(object sender, SKTouchEventArgs e)
        {
            if (e.ActionType == SKTouchAction.Pressed
                || e.ActionType == SKTouchAction.Moved)
            {
                var _touchPoint = e.Location;

                //Pulling back the arrow, getting ready to fire..

                if (pullingArrow)
                {
                    newArrowEnd = _touchPoint;
                }
                else
                {
                    // Touching in the arrow-pulling-back circle will trigger the pulling back mode.
                    if (Math.Abs(_touchPoint.Length - newArrowStart.Length) < 64)
                    {
                        pullingArrow = true;
                        newArrowEnd = _touchPoint;
                    }
                }
            }


            if (e.ActionType == SKTouchAction.Released)
            {
                // The user let go - can we launch an arrow?

                if (pullingArrow)
                {
                    // Fire!
                    ArrowClass newArrow = new ArrowClass();
                    var angle = Math.Atan2(newArrowStart.Y - newArrowEnd.Y, newArrowStart.X - newArrowEnd.X);
                    var magnitude = distanceBetweenPoints(newArrowStart, newArrowEnd);
                    if (newArrowStart.Y < newArrowEnd.Y)
                    {
                        // Check in case the player is accidentally going to shoot themselves in the foot.
                        newArrow.Fire((float)angle, (float)magnitude);
                        arrows.Add(newArrow);
                    }
                    pullingArrow = false;
                }

            }

            e.Handled = true;
        }


        private int distanceBetweenPoints(SKPoint a, SKPoint b)
        {
            var magnitude = (Math.Pow(a.Y - b.Y, 2) + Math.Pow(a.X - b.X, 2)) / 2000;
            return (int)magnitude;

        }
        private SKBitmap LoadBitmap(string resourceID)
        {
            // Load the bitmap given its name

            Assembly assembly = GetType().GetTypeInfo().Assembly;
            using (Stream stream = assembly.GetManifestResourceStream(resourceID))
            {
                if (stream != null)
                {
                    return SKBitmap.Decode(stream);
                }
                return null;
            }

        }
    }
}
