﻿using System;

namespace DuoGame
{
    class ArrowClass
    {
        int x, y, dx, dy;
        bool active;
        const int screenheight = 2700;
        const int screenwidth = 1800;
        bool reachedUpperScreen;

        public void Move()
        {
            // Move the arrow
            x = x + dx;
            y = y + dy;

            // If on upper screen, dy gets smaller thanks to 'gravity' 
           
            if (reachedUpperScreen)
            {
                dy = dy + 1;
                if (y > screenheight / 2 ) active = false;
            }
            else
            {
                if (y < screenheight/2)
                    reachedUpperScreen = true;
            }

            // Stop the arrow when it goes out of range
            if ((x < 0) || (x > screenwidth) || (y > screenheight)) active = false;
        }

        public void Fire(float angle, float magnitude)
        {
            // Launch the arrow in the right direction and speed
            y = screenheight - 320; 
            x = screenwidth / 2 ; 
            dx = (int)(magnitude * Math.Cos(angle)); 
            dy = (int)(magnitude * Math.Sin(angle));
            active = true;
            reachedUpperScreen = false;
        }

        public SkiaSharp.SKPoint GetStartLocation()
        {
            return new SkiaSharp.SKPoint(x, y);
        }

        public SkiaSharp.SKPoint GetEndLocation()
        {
            return new SkiaSharp.SKPoint(x + dx*4,  y + dy*4);
        }

        public bool GetState()
        {
            return active;
        }

    }
}
