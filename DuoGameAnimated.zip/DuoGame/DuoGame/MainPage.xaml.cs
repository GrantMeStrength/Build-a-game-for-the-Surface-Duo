﻿using SkiaSharp;
using SkiaSharp.Views.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace DuoGame
{
    public partial class MainPage : ContentPage
    {
        Stopwatch stopwatch = new Stopwatch();
        float x = 200, y = 200;
        float dx = 11, dy = 7;
        bool pageIsActive = true;
        SKBitmap ninjaCatBitmap;

        public MainPage()
        {
            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            // This method is automatically called when the app appears

            base.OnAppearing();

            // Load the bitmaps
            ninjaCatBitmap = LoadBitmap("DuoGame.Images.ninjacat.png");

            // Start the animation loop
            AnimationLoop();
        }

        void OnCanvasViewPaintSurface(object sender, SKPaintSurfaceEventArgs args)
        {
            // This is called whenever the screen needs redrawn

            SKSurface surface = args.Surface;
            SKCanvas canvas = surface.Canvas;

            // Clear the screen
            canvas.Clear();

            // Draw the bitmap
            canvas.DrawBitmap(ninjaCatBitmap, x, y);
        }

        async Task AnimationLoop()
        {
            // This just keeps going until the app isn't
            // visible any more.

            while (pageIsActive)
            {
                stopwatch.Start();

                x = x + dx;
                if (x < 0 || x > 1024) dx = -dx;
               
                y = y + dy;
                if (y < 0 || y > 1024) dy = -dy;

                canvasView.InvalidateSurface();
                await Task.Delay(TimeSpan.FromSeconds(1.0 / 30.0));

                stopwatch.Stop();
            }
        }

        private void OnTouch(object sender, SKTouchEventArgs e)
        {
           
        }

        protected override void OnDisappearing()
        {
            // This is called when the app is no longer visible

            base.OnDisappearing();
            pageIsActive = false;
        }

        public SKBitmap LoadBitmap(string resourceID)
        {
            // Load the bitmap given its name

            Assembly assembly = GetType().GetTypeInfo().Assembly;
            using (Stream stream = assembly.GetManifestResourceStream(resourceID))
            {
                if (stream != null)
                {
                    return SKBitmap.Decode(stream);
                }
                return null;
            }

        }
    }
}
